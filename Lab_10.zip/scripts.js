// scripts.js
$(document).ready(function() {
    const images = [
        { src: 'path/to/image1.jpg', category: 'nature' },
        { src: 'path/to/image2.jpg', category: 'architecture' },
        // Add more images
    ];

    function displayImages(category) {
        const gallery = $('#gallery');
        gallery.empty();
        const filteredImages = category === 'all' ? images : images.filter(img => img.category === category);
        filteredImages.forEach(image => {
            gallery.append(`
                <div class="gallery-item" data-category="${image.category}">
                    <img src="${image.src}" alt="${image.category}">
                </div>
            `);
        });
    }

    $('.filter').on('click', function() {
        const category = $(this).data('category');
        displayImages(category);
    });

    displayImages('all');
});
// Inside your $(document).ready(function() { ... })
function setupLightbox() {
    $('body').append('<div id="lightbox"><img id="lightbox-img"><span id="lightbox-close">&times;</span></div>');
    
    $('.gallery-item img').on('click', function() {
        $('#lightbox-img').attr('src', $(this).attr('src'));
        $('#lightbox').show();
    });

    $('#lightbox, #lightbox-close').on('click', function() {
        $('#lightbox').hide();
    });
}

setupLightbox();
// Add inside the displayImages function
$('.gallery-item').hide().fadeIn(500);
